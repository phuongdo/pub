package nl.vu.cs.align.algorithm;

import nl.vu.cs.align.matrix.*;

public interface MatrixInit {
	void init(AlignData data);
}
