package nl.vu.cs.align.algorithm;

public class LocalAlignSimpleTest extends AlignTest {

	public LocalAlignSimpleTest(String arg0) {
		super(arg0);
	}

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testAlign() {
	}

	public void testLocalAlign() {
	}

}
