package nl.vu.cs.align.algorithm;

import nl.vu.cs.align.matrix.*;

public interface MatrixFill {
	void fill(AlignData data);
}
