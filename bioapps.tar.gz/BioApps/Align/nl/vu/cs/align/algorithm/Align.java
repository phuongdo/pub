package nl.vu.cs.align.algorithm;

import nl.vu.cs.align.matrix.*;

public abstract class Align {
	
	abstract public float align(AlignData data);

}
