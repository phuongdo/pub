package nl.vu.cs.align.algorithm;


public class AlignDDPTest extends AlignTest {

	/**
	 * Constructor for AlignDDPTest.
	 * @param arg0
	 */
	public AlignDDPTest(String arg0) {
		super(arg0);
	}
	
	public void testAlignDDP() {
		// fake test
	}


}
