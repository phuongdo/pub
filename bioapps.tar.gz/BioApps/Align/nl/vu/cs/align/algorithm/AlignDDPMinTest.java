package nl.vu.cs.align.algorithm;


/**
 * @author Administrator
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class AlignDDPMinTest extends AlignDDPTest {

	/**
	 * Constructor for AlignDDPMinTest.
	 * @param arg0
	 */
	public AlignDDPMinTest(String arg0) {
		super(arg0);
	}

/*	public void testAlignDDPMin1() {
		AlignDDPMin ddp = new AlignDDPMin(new CompleteAlignSeqsSimple());
		AlignData data = new AlignDataAffineGotoh("AA", "AA", -1, -1, testSubst);
		_testForMaxValue(ddp, data, MA);
	}

	public void testAlignDDPMin2() {
		AlignDDPMin ddp = new AlignDDPMin(new CompleteAlignSeqsSimple());
		AlignData data = new AlignDataAffineGotoh("ABA", "ACA", -1, -1, testSubst);
		_testForMaxValue(ddp, data, MA);
	}

	public void testAlignDDPMin3() {
		AlignDDPMin ddp = new AlignDDPMin(new CompleteAlignSeqsSimple());
		AlignData data = new AlignDataAffineGotoh("ACA", "ABA", -1, -1, testSubst);
		_testForMaxValue(ddp, data, MA);
	}
*/
}
