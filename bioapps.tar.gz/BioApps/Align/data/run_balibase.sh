nice -19 java -server -Xmx128m -cp ~/workspace/Align:/home/radek/workspace/PNGEncoder nl.vu.cs.align.SelfSimilarity -max 1000 -o /tmp -procNr 0 -procTotal 1 -matrix ~/workspace/Align/BLOSUM62 $*
