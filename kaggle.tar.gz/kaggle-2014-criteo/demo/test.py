import hashlib, csv, math, os, pickle, subprocess

def read_freqent_feats(threshold=10):
    frequent_feats = set()
    for row in csv.DictReader(open('../fc.trva.t10.txt')):
        if int(row['Total']) < threshold:
            continue
        frequent_feats.add(row['Field']+'-'+row['Value'])
    return frequent_feats

frequent_feats = read_freqent_feats(10)
for feat in frequent_feats:
    print(feat)